import time
run=True
while run:
    enter_age=input("Ведите ваш год рождения:")
    year = 2022
    try:
        enter_age = int(enter_age)
        print("вам"+ str(year-enter_age) +"лет")
        run=False
        time.sleep(5)
    except ValueError:
        print("ошибка")
